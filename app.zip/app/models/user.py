from typing import Optional
from sqlmodel import SQLModel, Field

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    matricule: str = Field(index=True, unique=True)
    last_name: str
    first_name: str
    email: str = Field(index=True, unique=True)
    role: str = Field(default="PP Technician")
    hashed_password: str
